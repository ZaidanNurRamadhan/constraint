package com.example.constrainttugas

import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {
    private lateinit var emailInput: TextInputEditText
    private lateinit var fullnameInput: TextInputEditText
    private lateinit var usernameInput: TextInputEditText
    private lateinit var passwordInput: TextInputEditText
    private lateinit var signUpButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        emailInput = findViewById(R.id.email)
        fullnameInput = findViewById(R.id.fullname)
        usernameInput = findViewById(R.id.username)
        passwordInput = findViewById(R.id.password)
        signUpButton = findViewById(R.id.btn)

        // Set onClickListener pada button
        signUpButton.setOnClickListener {
            // Mengambil nilai input dari pengguna
            val email = emailInput.text.toString().trim()
            val fullname = fullnameInput.text.toString().trim()
            val username = usernameInput.text.toString().trim()
            val password = passwordInput.text.toString().trim()

            // Cek apakah ada input yang kosong
            if (email.isEmpty() || fullname.isEmpty() || username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            } else {

                val message = "Email: $email\nFullname: $fullname\nUsername: $username\nPassword: $password"

                val toast = Toast.makeText(this, message, Toast.LENGTH_LONG)

                toast.setGravity(Gravity.TOP, 1, 0)

                toast.show()
            }
        }

    }
}